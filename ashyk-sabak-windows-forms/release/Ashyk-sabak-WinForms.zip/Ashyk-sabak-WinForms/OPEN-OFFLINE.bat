@echo off
start "" "%~dp0presentation\index.html"
