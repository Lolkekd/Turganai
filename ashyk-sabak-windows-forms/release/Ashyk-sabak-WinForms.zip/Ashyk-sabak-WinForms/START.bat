@echo off
chcp 65001 >nul
set "PAGE=%~dp0presentation\index.html"
if not exist "%PAGE%" (
  echo Файл presentation\index.html не найден. Распакуйте архив полностью.
  pause
  exit /b 1
)
where msedge >nul 2>nul
if %errorlevel%==0 (
  start "" msedge --new-window --start-fullscreen "%PAGE%"
  exit /b 0
)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --new-window --start-fullscreen "%PAGE%"
  exit /b 0
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --new-window --start-fullscreen "%PAGE%"
  exit /b 0
)
start "" "%PAGE%"
